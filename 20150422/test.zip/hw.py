#!/usr/bin/python

print "hello world"

s = """The roller 
fafafsadf
"""


print s
