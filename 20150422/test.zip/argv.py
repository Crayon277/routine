import sys
print "the argv is :"
for i in sys.argv:
    print i
